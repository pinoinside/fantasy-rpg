Fantasy RPG Demo

Avvio:
Aprire con un server locale (es. VS Code Live Server).

Include:
- motore JS
- lancio D20
- combattimento base
- dati JSON separati
