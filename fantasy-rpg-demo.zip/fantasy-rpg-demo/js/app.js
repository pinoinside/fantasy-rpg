import {Engine} from './engine.js';

let engine;

const hero={
 name:"Arthas",
 race:"Umano",
 class:"Guerriero",
 strength:12
};

const enemy={
 name:"Lupo",
 hp:20
};

engine=new Engine(hero,enemy);

document.getElementById("hero").innerText =
 `${hero.name} - ${hero.race} ${hero.class}`;

log("Un lupo appare!");

window.attack=()=>{
 log(engine.attack());
};

function log(t){
 document.getElementById("log").innerText += "\n"+t;
}