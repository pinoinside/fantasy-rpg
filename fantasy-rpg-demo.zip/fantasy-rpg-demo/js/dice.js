export function roll(count,sides){
 let t=0;
 for(let i=0;i<count;i++)
  t+=Math.floor(Math.random()*sides)+1;
 return t;
}