import {roll} from './dice.js';

export class Engine{
 constructor(hero,enemy){
  this.hero=hero;
  this.enemy=enemy;
 }
 attack(){
  let d=roll(1,20);
  let dmg=d+this.hero.strength;
  this.enemy.hp-=dmg;
  return `D20: ${d}\nDanno: ${dmg}\n${this.enemy.name} HP: ${this.enemy.hp}`;
 }
}