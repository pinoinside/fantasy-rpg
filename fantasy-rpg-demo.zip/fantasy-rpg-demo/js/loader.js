export async function load(path){
 const r=await fetch(path);
 return await r.json();
}